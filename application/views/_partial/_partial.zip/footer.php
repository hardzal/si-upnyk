<footer class="page-footer-light font-small grey lighten-1">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">Copyright ©:
    <a>Program Studi Sistem Informasi 2020</a>
  </div>
  <!-- Copyright -->

</footer>