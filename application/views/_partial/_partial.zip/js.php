<!-- jQuery -->
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.min.js')?>"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="<?php echo base_url('assets/js/popper.min.js')?>"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="<?php echo base_url('assets/js/mdb.min.js')?>"></script>
<!-- Your custom scripts (optional) -->
<script type="text/javascript" src="<?php echo base_url('assets/js/javascript.js')?>"></script>