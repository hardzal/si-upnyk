<a href="http://fti.upnyk.ac.id/">
	<img class="img-fluid" src="<?php echo base_url('assets/assets2/img/cbis.png')?>">
	<br>
	<br>
</a>

<a href="http://upnyk.ac.id/">
	<img class="img-fluid" src="<?php echo base_url('assets/assets2/img/upn.png')?>">
	<br>
	<br>
</a>

<a href="http://jurnal.upnyk.ac.id/">
	<img class="img-fluid" src="<?php echo base_url('assets/assets2/img/jurnal.png')?>">
	<br>
	<br>
</a>

<a href="http://pmb.upnyk.ac.id/">
	<img class="img-fluid" src="<?php echo base_url('assets/assets2/img/pmb.png')?>">
	<br>
	<br>
</a>
