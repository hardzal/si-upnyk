<div class="container-fluid grey lighten-3">
  
  <img class="logo-header" src="<?php echo base_url('assets/img/sisfo.png')?>">
  </div>
  <nav class="navbar sticky-top navbar-expand-md navbar-light grey lighten-1">
    <button class="navbar-toggler grey" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto navi">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('index.php')?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
        aria-expanded="false">Profil
      </a>
      <div class="dropdown-menu dropdown-primary" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="<?php echo base_url('index.php/sisfo/visimisi')?>">Visi & Misi</a>
      </div>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
        aria-expanded="false">Data Personil
      </a>
      <div class="dropdown-menu dropdown-primary" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="<?php echo base_url('index.php/sisfo/dosen')?>">Dosen</a>
        <a class="dropdown-item" href="<?php echo base_url('index.php/sisfo/tendik')?>">Tenaga Pendidik</a>
      </div>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
        aria-expanded="false">Akademik
      </a>
      <div class="dropdown-menu dropdown-primary" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="<?php echo base_url('index.php/sisfo/kurikulum')?>">Kurikulum</a>
        <a class="dropdown-item" href="<?php echo base_url('index.php/sisfo/akademik')?>">Kalender Akademik</a>
        <a class="dropdown-item" href="http://si.upnyk.ac.id/siapps/index.php">Student Page</a>
      </div>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('index.php/sisfo/berita')?>">Berita</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('index.php/sisfo/download')?>">Download</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
        aria-expanded="false">Kuisioner
      </a>
      <div class="dropdown-menu dropdown-primary" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="https://bit.ly/2XXO9Zw">Alumni</a>
        <a class="dropdown-item" href="https://bit.ly/2JCqLHN">Pengguna alumni</a>
        <a class="dropdown-item" href="https://bit.ly/2Y80LwY">Mahasiswa</a>
        <a class="dropdown-item" href="https://bit.ly/2NVM64j">Atasan</a>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo base_url('index.php/sisfo/kontak')?>">Kontak</a>
    </li>
  </ul>
</div>
</nav>