<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $this->load->view("_partial/head.php") ?>
</head>
<body>

  <!-- Start your project here-->
  <!-- load Navbar -->
  <?php $this->load->view("_partial/navbar.php") ?>
  <!-- End Navbar -->

  <div class="row1" id="topSection">
    <!--Carousel Wrapper-->
    <div id="carousel-example-1z" class="carousel slide carousel-fade col-md-12" data-ride="carousel">
      <!--Indicators-->
      <ol class="carousel-indicators">
        <?php 
        foreach ($slide as $key => $value) {
          $active = ($key == 0) ? 'active' : '';
          echo '<li data-target="#carousel-example-1z" data-slide-to="' . $key . '" class="' . $active . '"></li>';
        }
        ?>
      </ol>
      <!--/.Indicators-->
      <!--Slides-->
      <div class="carousel-inner" role="listbox">
        <?php 
        foreach ($slide as $key => $value) {
          $active = ($key == 0) ? 'active' : '';
          echo '<div class="carousel-item ' . $active . '"><a><img class="d-block img-fluid" src="' . base_url('assets/images/'). $value['file']   . '" alt="'.$value['file'].'"></a></div>';
        }
        ?>            
      </div>
      <!--/.Slides-->
      <!--Controls-->
      <a class="carousel-control-prev" href="#carousel-example-1z" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carousel-example-1z" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
      <!--/.Controls-->
    </div>
    <!--/.Carousel Wrapper-->
  </div>
  <!--Main layout-->
  <div class="container-fluid grey lighten-5">
    <div class="container badan-home">
      <hr>
      <div class="row">
        <div class="col-md-8">
          <h4 class=" mb-3 text-center text-uppercase">Berita Terkini</h4>
          <hr>
          <!-- Row Berita -->
          <div class="row">
            <?php 
              $count = 0;
              foreach ($berita as $key => $value) {
                if ($count < 3) {
            ?>
            <!-- Card -->
            <div class="col-md-4 mb-4">
              <!-- Card image -->
              <img class="card-img-top" src="<?php echo base_url('assets/images/'.$value->file)?>" alt="Card image cap">

              <!-- Card content -->
              <div class="card-body grey lighten-2">
                <!-- Title -->
                <h5 class="card-title text-capitalize font-weight-bold"><a href="<?php echo base_url('index.php/sisfo/detailberita/'.$value->id)?>"><?php echo $value->judul; ?></a></h5>
                <!-- Text -->
                <small>
                  <p class="card-text text-uppercase"><?php echo date("d F Y", strtotime($value->tgl)); ?></p>
                </small>
              </div>
            </div>
            <!-- end Card -->
            <?php 
                }
                $count++;
              }
            ?>
          </div>
          <!-- Row Berita -->

          <!-- Row Berita Lainnya -->
          <div class="row">
            <div class="col-md-12 berita-lain">
              <h4 class=" mb-3 text-uppercase">Berita Lain</h4>
              <hr>
              <ul class="list-unstyled">
                <?php 
                  $count = 0;
                  foreach ($berita as $key => $value) {
                    if ($count > 2) {
                ?>
                <li class="mb-2">
                  <small>
                  <!-- Title -->
                  <h5 class="card-title text-capitalize font-weight-bold mb-1"><a href="<?php echo base_url('index.php/sisfo/detailberita/'.$value->id)?>"><?php echo $value->judul; ?></a></h5>
                  <!-- Text -->
                  <small>
                    <p class="card-text text-uppercase"><?php echo date("d F Y", strtotime($value->tgl)); ?></p>
                  </small>
                  </small>
                </li>
                <hr id="hrBeritalain">
                <?php 
                    }
                    $count++;
                  }
                ?>
              </ul>
            </div>
          </div>
          <!-- Row Berita Lainnya -->
        </div>
        <!-- Link Terkait -->
        <div class="col-md-4">
          <h4 class=" mb-3 text-center text-uppercase">Link Terkait</h4>
          <hr>
          <!-- Load Link Terkait -->
          <?php $this->load->view("_partial/linkTerkait.php") ?>
        </div>
      </div>
    </div>

    <!--Back to Top-->
    <button onclick="topFunction()" id="backToTop" title="Go to top">
      <i class="fa fa-arrow-up"></i>
    </button> 
  </div>
  <!--End Main layout-->
  <!-- Load Footer -->
  <?php $this->load->view("_partial/footer.php") ?>
  <!-- End Footer -->
  <!-- End your project here-->

  <!-- Load JS -->
  <?php $this->load->view("_partial/js.php") ?>

</body>
</html>
