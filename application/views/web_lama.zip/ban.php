<!-- banner -->
	<div class="w3ls-banner">
		<!-- banner-text -->
		
		<!-- Start WOWSlider.com BODY section -->
		<div id="wowslider-container1">
		<div class="ws_images"><ul>
				<li><img src="<?php echo base_url('assets/slider/data1/images/13032016064848.jpg') ?>" alt="13032016064848" title="13032016064848" id="wows1_0"/></li>
				<li><a href="http://wowslider.net"><img src="<?php echo base_url('assets/slider/data1/images/30032016040126.jpg') ?>" alt="css image slider" title="30032016040126" id="wows1_1"/></a></li>
				<li><img src="<?php echo base_url('assets/slider/data1/images/130320160623241.jpg') ?>" alt="130320160623241" title="130320160623241" id="wows1_2"/></li>
			</ul></div>
		<div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">jquery carousel slider</a> by WOWSlider.com v8.8</div>
		<div class="ws_shadow"></div>
		</div>	
		<script type="text/javascript" src="<?php echo base_url('assets/slider/engine1/wowslider.js') ?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/slider/engine1/script.js') ?>"></script>
		<!-- End WOWSlider.com BODY section -->
				
		
		
		<!-- //banner-text -->  
	</div>	
	<!-- //banner -->