	<!--start: Container -->
		<div class="container">
			<!--start: Header -->
			<header><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
				<!--start: Row -->
				<div class="row">
					<!--start: Logo -->
					
					<!--end: Logo -->
				<!--start: Logo -->
					<div class="logo span8">
						<a class="brand" href="#"><img src="<?php echo base_url('assets/img/sisfo.png')?>" width="80%" class="img-responsive"></a>
					</div>
					<!--end: Logo -->
                </div>
				<!--end: Row -->
						
			</header>
			<!--end: Header-->
			<br>
			<!--start: Navigation-->	
			<div class="navbar navbar-inverse">
    			<div class="navbar-inner">
        			<div class="container">
          				<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            				<span class="icon-bar"></span>
            				<span class="icon-bar"></span>
            				<span class="icon-bar"></span>
          				</a>
          				<div class="nav-collapse collapse">
            				<ul class="nav">
              					<li><a href="<?php echo base_url('index.php/sisfo/index')?>">Beranda</a></li>
              					<li class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Profil <b class="caret"></b></a>
                					<ul class="dropdown-menu">
                  						<li><a href="<?php echo base_url('index.php/sisfo/visimisi')?>">Visi Misi</a></li>
                  						</ul>
              					</li>
					<li class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Data Personil <b class="caret"></b></a>
                					<ul class="dropdown-menu">
                  						<li><a href="<?php echo base_url('index.php/sisfo/dosen')?>">Dosen</a></li>
                  						<li><a href="<?php echo base_url('index.php/sisfo/tendik')?>">Tendik</a></li>
                  						</ul>
              					</li>
					<li class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Akademik <b class="caret"></b></a>
                					<ul class="dropdown-menu">
                  						<li><a href="<?php echo base_url('index.php/sisfo/kurikulum')?>">Kurikulum</a></li>
                  						<li><a href="<?php echo base_url('index.php/sisfo/akademik')?>">Kalendar Akademik</a></li>
                  						<li><a href="<?php echo base_url('/siapps/index.php')?>">Student Page</a></li>
                  						</ul>
              					</li>
					<li><a href="<?php echo base_url('index.php/sisfo/berita')?>">Berita</a></li>
					<li><a href="<?php echo base_url('index.php/sisfo/download')?>">Download</a></li>
					<li class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Kuisioner <b class="caret"></b></a>
                					<ul class="dropdown-menu">
                  						<li><a href="https://bit.ly/2XXO9Zw">Alumni</a></li>
                  						<li><a href="https://bit.ly/2JCqLHN">Pengguna Alumni</a></li>
                  						<li><a href="https://bit.ly/2Y80LwY">Mahasiswa</a></li>
                  						<li><a href="https://bit.ly/2NVM64j">Atasan</a></li>
                  						</ul>
              					</li>
					<li><a href="<?php echo base_url('index.php/sisfo/kontak')?>">Kontak</a></li>
              					
            				</ul>
          				</div>
        			</div>
      			</div>
    		</div>
			<!--end: Navigation-->
		</div>
		<!--end: Container-->