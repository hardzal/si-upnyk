<!-- navigation -->
	<div class="top-nav w3-agiletop">
		<div class="container" style="padding-left:5px;margin-left:15px;margin-right:5px;margin-right:5px;">
			<div class="navbar-header w3llogo" >
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>  
				<h1><a href="index.html">INFORMATIKA <span>Beda Tapi Satu<span></a></h1> 
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<div class="w3menu navbar-right">
					<ul class="nav navbar">
						<li><a href="<?php echo base_url('index.php/ifupnyk/index')?>" class="active">Home</a></li>
						
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">Profil <b class="caret"></b></a>
								<ul class="dropdown-menu agile_short_dropdown">
									<li><a href="<?php echo base_url('index.php/ifupnyk/visimisi')?>">Visi & Misi</a></li>
									<li><a href="<?php echo base_url('index.php/ifupnyk/strukor')?>">Struktur Organisasi</a></li>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">Data Personil<b class="caret"></b></a>
								<ul class="dropdown-menu agile_short_dropdown">
									<li><a href="<?php echo base_url('index.php/ifupnyk/dosen')?>">Dosen</a></li>
									<li><a href="<?php echo base_url('index.php/ifupnyk/tendik')?>">Tendik</a></li>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">Akademik<b class="caret"></b></a>
								<ul class="dropdown-menu agile_short_dropdown">
									<li><a href="<?php echo base_url('index.php/ifupnyk/kalendar')?>">Kalendar Akademik</a></li>
									<li><a href="">Daftar Kurikulum</a></li>
									<li><a href="<?php echo base_url('index.php/ifupnyk/prestasi')?>">Prestasi</a></li>
									<li><a href="<?php echo base_url('index.php/ifupnyk/kp')?>">Kerja Praktek</a></li>
									<li><a href="<?php echo base_url('index.php/ifupnyk/skripsi')?>">Skripsi</a></li>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">Sarana & Prasarana<b class="caret"></b></a>
								<ul class="dropdown-menu agile_short_dropdown">
									<li><a href="icons.html">Lab</a></li>
									
								</ul>
							</li>
						
						<li><a href="about.html">Evaluasi</a></li>
											
						<li><a href="gallery.html">Berita</a></li>
						<li><a href="contact.html">Download</a></li>
						<li><a href="contact.html">Kontak</a></li>
					</ul>
				</div> 
				<div class="clearfix"> </div>  
			</div>
		</div>	
	</div>	
	<!-- //navigation -->